const { WebClient, ErrorCode } = require('@slack/web-api');
// Initialize
const web = new WebClient();
let result = 'base message';

// Given some known conversation ID (representing a public channel, private channel, DM or group DM)
exports.postToSlack = async (conversationId = 'G010NN0PJ1X', messageText = 'Morning friends! Coffee time?', slackToken) => {
  
  try {
    // Read a token from the environment variables
    const token = slackToken || process.env.SLACK_TOKEN;
    // Post a message to the channel, and await the result.
    // Find more arguments and details of the response: https://api.slack.com/methods/chat.postMessage
    result = await web.chat.postMessage({
      token,
      text: messageText,
      channel: conversationId,
    });
  } catch (error) {
    // Check the code property, and when its a PlatformError, log the whole response.
    if (error.code === ErrorCode.PlatformError) {
      console.log(error.data)
      throw new Error(error.data.error)
    } else {
      // Some other error!
      console.log('Well, that was unexpected.');
    }
  }
  
  // return a 200 response
  const response =
    result.ok ?
      {
        statusCode: 200,
        body: JSON.stringify({
          message: `Successfully send message ${result.ts} in conversation ${conversationId}`,
        }),
      } :
      {
        statusCode: 400,
        body: JSON.stringify({
          message: `Had an issue trying to post into conversation.`,
        }),
      };

  return response;
};